#include <stdio.h>
#include <stdbool.h>

#define MAX_NOMBRE 100
#define MAX_INVENTOS 10

typedef struct invento{

	char nombre[MAX_NOMBRE];
	char tipo;
	int puntaje;

}invento_t;

void pedir_inventos(invento_t inventos[MAX_INVENTOS], int* tope_inventos){

	bool basta = false;
	char letra;
	while(!basta && (*tope_inventos <= MAX_INVENTOS)){

		printf("Queres ingresar un invento?[S/n]\n");
		scanf(" %c", &letra);
		if(letra == 'S'){
			printf("El nombre del invento:\n");
			scanf(" %[^\n]", inventos[(*tope_inventos)].nombre);
			printf("El tipo del invento:\n");
			scanf(" %c", &inventos[(*tope_inventos)].tipo);
			printf("El puntaje pa:\n");
			scanf("%i", &inventos[(*tope_inventos)].puntaje);
			(*tope_inventos)++;
		}else{
			basta = true;
		}
	}
}

void imprimir_invento_favorito(invento_t inventos[MAX_INVENTOS], int tope_inventos){

	//buscar puntaje mas alto y devolveria la pos
	//imprimo el nombre en la pos del puntaje mas alto.

}

int main(){

	invento_t inventos[MAX_INVENTOS];
	int tope_inventos = 0;

	pedir_inventos(inventos, &tope_inventos);


	return 0;
}

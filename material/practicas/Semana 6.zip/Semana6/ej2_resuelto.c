#include <stdio.h>
#include <stdbool.h>

#define MAX_NOMBRE 30
#define MAX_INVENTOS 100

const char AVENTURA = 'A';
const char SERVICIO = 'S';
const char ENTRETENIMIENTO = 'E';
const char FESTIVO = 'F';
const int PUNTAJE_MAYOR = 100;
const int PUNTAJE_MENOR = 0;
const int CANT_INVENTOS = 10;
const char NEGATIVO = 'n';

typedef struct invento{

	char nombre[MAX_NOMBRE];
	char tipo;
	int puntaje;

}invento_t;

void pedir_nombre(invento_t inventos[MAX_INVENTOS], int tope_inventos){

	printf("Nombre: ");
	scanf(" %[^\n]", inventos[tope_inventos].nombre);
}

bool es_tipo_valido(char tipo){

	return(tipo == AVENTURA || tipo == ENTRETENIMIENTO || tipo == SERVICIO || tipo == FESTIVO);
}

bool es_puntaje_valido(int puntaje){

	return((puntaje >= PUNTAJE_MENOR) && (puntaje <= PUNTAJE_MAYOR));
}

void pedir_tipo(invento_t inventos[MAX_INVENTOS], int tope_inventos){

	printf("Tipo: ");
	scanf(" %c", &(inventos[tope_inventos].tipo));
	while(!es_tipo_valido(inventos[tope_inventos].tipo)){
		printf("Tipo: ");
		scanf(" %c", &(inventos[tope_inventos].tipo));
	}
}

void pedir_puntaje(invento_t inventos[MAX_INVENTOS], int tope_inventos){

	printf("Puntaje: ");
	scanf("%i", &(inventos[tope_inventos].puntaje));
	while(!es_puntaje_valido(inventos[tope_inventos].puntaje)){
		printf("Puntaje: ");
		scanf("%i", &(inventos[tope_inventos].puntaje));
	}
}

void pedir_inventos(invento_t inventos[MAX_INVENTOS], int* tope_inventos){

	bool parar = false;
	char respuesta_phineas = 'S';
	while((*tope_inventos != CANT_INVENTOS) && !parar){

		printf("Quiere ingresar un invento? [S/n]\n");
		scanf(" %c", &respuesta_phineas);
		if(respuesta_phineas == NEGATIVO){
			parar = true;
		}else{
			pedir_nombre(inventos, *tope_inventos);
			pedir_tipo(inventos, *tope_inventos);
			pedir_puntaje(inventos, *tope_inventos);
			(*tope_inventos)++;
		}
	}
}

int buscar_invento_favorito(invento_t inventos[MAX_INVENTOS], int tope_inventos){

	int pos_puntaje_mayor = 0;
	int puntaje_mayor = inventos[pos_puntaje_mayor].puntaje;
	for (int i = 1; i < tope_inventos; i++){
		if(inventos[i].puntaje > puntaje_mayor){
			puntaje_mayor = inventos[i].puntaje;
			pos_puntaje_mayor = i;
		}
	}

	return pos_puntaje_mayor;

}

void mostrar_invento_favorito(invento_t inventos[MAX_INVENTOS], int tope_inventos){

	int posicion_buscada = buscar_invento_favorito(inventos, tope_inventos);
	printf("El invento favorito es: %s\n", inventos[posicion_buscada].nombre);

}

int main(){

	invento_t inventos[MAX_INVENTOS];
	int tope_inventos = 0;

	pedir_inventos(inventos, &tope_inventos);
	mostrar_invento_favorito(inventos, tope_inventos);

	return 0;
}
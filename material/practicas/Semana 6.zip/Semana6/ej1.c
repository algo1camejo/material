#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAX_NOMBRE 30
#define MAX_CAPITULOS 10

typedef struct libro{

	char nombre[MAX_NOMBRE];
	char genero;
	int cant_capitulos;
	float puntajes_capitulos[MAX_CAPITULOS];
	bool leido;
}libro_t;

libro_t inicializar_libro(char nombre[MAX_NOMBRE], char genero){

	libro_t libro;
	strcpy(libro.nombre, nombre);
	libro.genero = genero;
	libro.cant_capitulos = 0;
	libro.leido = false;

	return libro;
}

void puntuar_capitulo(libro_t* libro, float puntaje){

	libro->puntajes_capitulos[libro->cant_capitulos] = puntaje;
	libro->cant_capitulos++;
}

int main(){

	libro_t libro = inicializar_libro("Harry potter 1", 'F');
	printf("%s\n%c\n%i\n", libro.nombre, libro.genero, libro.cant_capitulos);
	puntuar_capitulo(&libro, 8.1f);
	printf("%s\n%c\n%i\n%f\n", libro.nombre, libro.genero, libro.cant_capitulos, libro.puntajes_capitulos[0]);

	return 0;
}
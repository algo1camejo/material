#include<stdio.h>
#include<stdbool.h>

#define MAX_NOMBRE 100
#define MAX_DESCRIPCION 200

typedef struct ensenianza{
    int id;
    char nombre[MAX_NOMBRE];
    char descripcion[MAX_DESCRIPCION];
    int sorpresa;
    char importante;
}ensenianza_t;


int leer_ensenianza(FILE* archivo, ensenianza_t* ensenianza){
    return fscanf(archivo, "%i|%[^|]|%[^|]|%i|%c\n", &(ensenianza->id), ensenianza->nombre, ensenianza->descripcion, &(ensenianza->sorpresa), &(ensenianza->importante));
}


bool actualizar_cuaderno(){
    FILE* cuaderno_nuevo = fopen("cuaderno_nuevo.csv", "r");
    if(cuaderno_nuevo == NULL){
        perror("No se pudo abrir el archivo.\n");
        return false;
    }

    FILE* cuaderno_original = fopen("cuaderno_original.csv", "r");
    if(cuaderno_nuevo == NULL){
        perror("No se pudo abrir el archivo.\n");
        fclose(cuaderno_nuevo);
        return false;
    }

    FILE* aux = fopen("aux.csv", "w");
    if(cuaderno_nuevo == NULL){
        perror("No se pudo abrir el archivo.\n");
        fclose(cuaderno_nuevo);
        fclose(cuaderno_original);
        return false;
    }


    ensenianza_t ensenianza_original;
    ensenianza_t ensenianza_nueva;

    int leidos_original = leer_ensenianza(cuaderno_original, &ensenianza_original);

    int leidos_nuevo = leer_ensenianza(cuaderno_nuevo, &ensenianza_nueva);

    while(leidos_nuevo != EOF && leidos_original != EOF){
        if(ensenianza_original.id == ensenianza_nueva.id) {
            fprintf(aux, "%i|%s|%s|%i|%c\n", ensenianza_nueva.id, ensenianza_nueva.nombre, ensenianza_nueva.descripcion, ensenianza_nueva.sorpresa, ensenianza_nueva.importante);

            leidos_original = leer_ensenianza(cuaderno_original, &ensenianza_original);

            leidos_nuevo = leer_ensenianza(cuaderno_nuevo, &ensenianza_nueva);

        } if (ensenianza_original.id < ensenianza_nueva.id){
            fprintf(aux, "%i|%s|%s|%i|%c\n", ensenianza_original.id, ensenianza_original.nombre, ensenianza_original.descripcion, ensenianza_original.sorpresa, ensenianza_original.importante);

            leidos_original = leer_ensenianza(cuaderno_original, &ensenianza_original);
        } if (ensenianza_original.id > ensenianza_nueva.id){
            fprintf(aux, "%i|%s|%s|%i|%c\n", ensenianza_nueva.id, ensenianza_nueva.nombre, ensenianza_nueva.descripcion, ensenianza_nueva.sorpresa, ensenianza_nueva.importante);

            leidos_nuevo = leer_ensenianza(cuaderno_nuevo, &ensenianza_nueva);
        }
    }

    while(leidos_original != EOF){
        fprintf(aux, "%i|%s|%s|%i|%c\n", ensenianza_original.id, ensenianza_original.nombre, ensenianza_original.descripcion, ensenianza_original.sorpresa, ensenianza_original.importante);

        leidos_original = leer_ensenianza(cuaderno_original, &ensenianza_original);
    }

    while(leidos_nuevo != EOF){
        fprintf(aux, "%i|%s|%s|%i|%c\n", ensenianza_nueva.id, ensenianza_nueva.nombre, ensenianza_nueva.descripcion, ensenianza_nueva.sorpresa, ensenianza_nueva.importante);

        leidos_nuevo = leer_ensenianza(cuaderno_nuevo, &ensenianza_nueva);
    }

    fclose(cuaderno_nuevo);
    fclose(cuaderno_original);
    fclose(aux);

    rename("aux.csv", "cuaderno_original.csv");
}

int main(){
    if(actualizar_cuaderno()){
        return 0;
    } else {
        return -1;
    }
}
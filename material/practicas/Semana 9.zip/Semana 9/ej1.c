#include<stdio.h>
#include<stdbool.h>
#include<string.h>

#define MAX_NOMBRE 200
#define MAX_INGREDIENTES 100

#define LACTEO 'L'
#define ESPECIA 'E'
#define VERDURA 'V'
#define FRUTA 'F'
#define OTRO 'O'

const int NO_ENCONTRADO = -1;

typedef struct ingrediente {
  char nombre[MAX_NOMBRE];
  int gramos_disponibles;
  char tipo; // (L)acteo, (E)specia, (V)erdura, (F)ruta, (O)tro
  bool es_rico;
} ingrediente_t;

void inicializar_ingredientes(ingrediente_t ingredientes[MAX_INGREDIENTES], int* tope_ingredientes) {
  (*tope_ingredientes) = 0;

  strcpy(ingredientes[*tope_ingredientes].nombre, "Arándanos");
  ingredientes[*tope_ingredientes].gramos_disponibles = 150;
  ingredientes[*tope_ingredientes].tipo = FRUTA;
  ingredientes[*tope_ingredientes].es_rico = true;
  (*tope_ingredientes)++;

  strcpy(ingredientes[*tope_ingredientes].nombre, "Cebolla dudosa");
  ingredientes[*tope_ingredientes].gramos_disponibles = 400;
  ingredientes[*tope_ingredientes].tipo = VERDURA;
  ingredientes[*tope_ingredientes].es_rico = false;
  (*tope_ingredientes)++;

  strcpy(ingredientes[*tope_ingredientes].nombre, "Crema");
  ingredientes[*tope_ingredientes].gramos_disponibles = 160;
  ingredientes[*tope_ingredientes].tipo = LACTEO;
  ingredientes[*tope_ingredientes].es_rico = true;
  (*tope_ingredientes)++;

  strcpy(ingredientes[*tope_ingredientes].nombre, "Frutilla");
  ingredientes[*tope_ingredientes].gramos_disponibles = 200;
  ingredientes[*tope_ingredientes].tipo = FRUTA;
  ingredientes[*tope_ingredientes].es_rico = true;
  (*tope_ingredientes)++;

  strcpy(ingredientes[*tope_ingredientes].nombre, "Harina");
  ingredientes[*tope_ingredientes].gramos_disponibles = 100;
  ingredientes[*tope_ingredientes].tipo = OTRO;
  ingredientes[*tope_ingredientes].es_rico = false;
  (*tope_ingredientes)++;

  strcpy(ingredientes[*tope_ingredientes].nombre, "Leche");
  ingredientes[*tope_ingredientes].gramos_disponibles = 20;
  ingredientes[*tope_ingredientes].tipo = LACTEO;
  ingredientes[*tope_ingredientes].es_rico = true;
  (*tope_ingredientes)++;

  strcpy(ingredientes[*tope_ingredientes].nombre, "Pimienta");
  ingredientes[*tope_ingredientes].gramos_disponibles = 10;
  ingredientes[*tope_ingredientes].tipo = ESPECIA;
  ingredientes[*tope_ingredientes].es_rico = false;
  (*tope_ingredientes)++;
}

void imprimir_ingrediente(ingrediente_t ingrediente) {
  printf(
    "Nombre: %s | Gramos: %i | Tipo: %c | Es rico: %i\n",
    ingrediente.nombre,
    ingrediente.gramos_disponibles,
    ingrediente.tipo,
    ingrediente.es_rico
  );
}

void imprimir_ingredientes(ingrediente_t ingredientes[MAX_INGREDIENTES], int tope_ingredientes) {
  for(int i = 0; i < tope_ingredientes; i++) {
    imprimir_ingrediente(ingredientes[i]);
  }
}

int buscar_ingrediente(char nombre[MAX_NOMBRE], ingrediente_t ingredientes[MAX_INGREDIENTES], int tope_ingredientes, int inicio, int fin){
  int centro =  (inicio+fin)/2;
  if(strcmp(nombre, ingredientes[centro].nombre) == 0){
    return centro;
  }
  if(inicio > fin){
    return -1;
  }
  if(strcmp(nombre, ingredientes[centro].nombre) < 0){
    fin = centro-1;
    return(buscar_ingrediente(nombre, ingredientes, tope_ingredientes, inicio, fin));
  }
  
  inicio = centro+1;
  return(buscar_ingrediente(nombre, ingredientes, tope_ingredientes, inicio, fin));
}

int buscar_ingrediente_recursivo(char nombre[MAX_NOMBRE], ingrediente_t ingredientes[MAX_INGREDIENTES], int tope_ingredientes){
  return(buscar_ingrediente(nombre, ingredientes, tope_ingredientes, 0, tope_ingredientes-1));
}

int buscar_ingrediente_iterativo(char nombre[MAX_NOMBRE], ingrediente_t ingredientes[MAX_INGREDIENTES],  int tope_ingredientes){
  int pos_buscada = NO_ENCONTRADO;
  int inicio = 0;
  int fin = tope_ingredientes-1;
  int centro = (inicio+fin)/2;
  while(pos_buscada == NO_ENCONTRADO && inicio <= fin){
    if(strcmp(nombre, ingredientes[centro].nombre) < 0){
      fin = centro -1;
    }else if(strcmp(nombre, ingredientes[centro].nombre) > 0){
      inicio = centro+1;
    }else{
      pos_buscada = centro;
    }
    centro = (inicio+fin)/2;
  }
  return(pos_buscada);
}

int main() {
  ingrediente_t ingredientes[MAX_INGREDIENTES];
  int tope_ingredientes;

  inicializar_ingredientes(ingredientes, &tope_ingredientes);
  imprimir_ingredientes(ingredientes, tope_ingredientes);

  int pos_harina = buscar_ingrediente_recursivo("Harina", ingredientes, tope_ingredientes);

  printf("Pos harina: %i\n", pos_harina);

  int pos_harina2 = buscar_ingrediente_iterativo("Harina", ingredientes, tope_ingredientes);

  printf("Pos harina: %i\n", pos_harina2);
  return 0;


}

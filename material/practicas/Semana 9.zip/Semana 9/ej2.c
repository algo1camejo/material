#include <stdio.h>
#include <stdbool.h>

#define MAX_FILAS 30
#define MAX_COLUMNAS 30
const char AGUA = 'A';
const char NEMO = 'N';

void inicializar_matriz_con_nemo(char matriz[MAX_FILAS][MAX_COLUMNAS], int tope_filas, int tope_columnas);
void inicializar_matriz_sin_nemo(char matriz[MAX_FILAS][MAX_COLUMNAS], int tope_filas, int tope_columnas);

bool esta_nemo(char matriz[MAX_FILAS][MAX_COLUMNAS], int tope_filas, int tope_columnas, int fila, int columna){
    if(matriz[fila][columna] == NEMO){
        return true;
    }

    if(fila == tope_filas-1 && columna == tope_columnas-1){
        return false;
    }

    if(columna < tope_columnas-1){
        return esta_nemo(matriz, tope_filas, tope_columnas, fila, columna+1);
    }else{
        return esta_nemo(matriz, tope_filas, tope_columnas, fila+1, 0);
    }
}

int main(){
    char oceano[MAX_FILAS][MAX_COLUMNAS];
    int tope_columnas = 20;
    int tope_filas = 20;

    inicializar_matriz_con_nemo(oceano, tope_filas,tope_columnas);
    bool esta_nemo1 = esta_nemo(oceano, tope_filas, tope_columnas, 0, 0);
    if(esta_nemo1){
        printf("Nemo esta\n");
    }else{
        printf("Nemo se fue\n");
    }
    return 0;
}







void inicializar_matriz_con_nemo(char matriz[MAX_FILAS][MAX_COLUMNAS], int tope_filas, int tope_columnas){
    for(int i = 0; i < tope_filas; i++){
        for(int j = 0; j < tope_columnas; j++){
            matriz[i][j] = AGUA;
        }
    }

    matriz[6][15] = NEMO;
}


void inicializar_matriz_sin_nemo(char matriz[MAX_FILAS][MAX_COLUMNAS], int tope_filas, int tope_columnas){
    for(int i = 0; i < tope_filas; i++){
        for(int j = 0; j < tope_columnas; j++){
            matriz[i][j] = AGUA;
        }
    }
}
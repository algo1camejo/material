#ifndef _ENANITOS_H_
#define _ENANITOS_H_

#include <stdbool.h>

#define MAX_NOMBRE 50
#define MAX_ENANITOS 10

typedef struct enanito{

	char nombre[MAX_NOMBRE];
	int estatura; //cm
	bool es_alergico;

}enanito_t;

/*
 * Pre : El tope debe estar inicializado en 0.
 * Pos : Carga el vector de enanitos en todos sus campos y su tope.
 */ 

void cargar_enanitos(enanito_t enanitos[MAX_ENANITOS], int* tope_enanitos);

#endif //_ENANITOS_H_
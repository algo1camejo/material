#include "enanitos.h"
#include <stdio.h>
#include <stdbool.h>
#include <string.h>

int posicion_mas_baja(enanito_t enanitos[MAX_ENANITOS], int tope_enanitos, int inicio_busqueda){

	int posicion_baja = inicio_busqueda;
	enanito_t enano_pequenio = enanitos[inicio_busqueda];
	for (int i = inicio_busqueda +1; i < tope_enanitos; ++i){
		if(enanitos[i].estatura < enano_pequenio.estatura){
			posicion_baja = i;
			enano_pequenio = enanitos[i];
		}else if(enanitos[i].estatura == enano_pequenio.estatura &&
				strcmp(enanitos[i].nombre, enano_pequenio.nombre) < 0){
			posicion_baja = i;
			enano_pequenio = enanitos[i];
		}
	}

	return posicion_baja;
}

void ordenar_enanitos(enanito_t enanitos[MAX_ENANITOS], int tope_enanitos){

	int menor_pos;
	enanito_t enano_aux;
	for (int i = 0; i < tope_enanitos; ++i){
		menor_pos = posicion_mas_baja(enanitos, tope_enanitos, i);
		//lo optimo es modularizar pero no tenemos tiempo aaaa
		enano_aux = enanitos[i];
		enanitos[i] = enanitos[menor_pos];
		enanitos[menor_pos] = enano_aux;
	}
}

int main(){

	enanito_t enanitos[MAX_ENANITOS];
	int tope_enanitos = 0;

	cargar_enanitos(enanitos, &tope_enanitos);
	printf("S/O\n");
	for (int i = 0; i < tope_enanitos; ++i)
	{
		printf("NOMBRE %s\n", enanitos[i].nombre);
		printf("ESTATURA: %i\n", enanitos[i].estatura);
	}

	ordenar_enanitos(enanitos, tope_enanitos);

	printf("\nORDENADO\n");

	for (int i = 0; i < tope_enanitos; ++i)
	{
		printf("NOMBRE %s\n", enanitos[i].nombre);
		printf("ESTATURA: %i\n", enanitos[i].estatura);
	}
}
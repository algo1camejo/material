#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "enanitos.h"

void cargar_enanitos(enanito_t enanitos[MAX_ENANITOS], int* tope_enanitos){

	strcpy(enanitos[(*tope_enanitos)].nombre, "Dormilon");
	enanitos[(*tope_enanitos)].estatura = 30;
	enanitos[(*tope_enanitos)].es_alergico = true;

	(*tope_enanitos)++;

	strcpy(enanitos[(*tope_enanitos)].nombre, "Mudito");
	enanitos[(*tope_enanitos)].estatura = 31;
	enanitos[(*tope_enanitos)].es_alergico = false;
	
	(*tope_enanitos)++;

	strcpy(enanitos[(*tope_enanitos)].nombre, "Gruñon");
	enanitos[(*tope_enanitos)].estatura = 23;
	enanitos[(*tope_enanitos)].es_alergico = false;

	(*tope_enanitos)++;

	strcpy(enanitos[(*tope_enanitos)].nombre, "Sabio");
	enanitos[(*tope_enanitos)].estatura = 35;
	enanitos[(*tope_enanitos)].es_alergico = false;

	(*tope_enanitos)++;

	strcpy(enanitos[(*tope_enanitos)].nombre, "Estornudo");
	enanitos[(*tope_enanitos)].estatura = 23;
	enanitos[(*tope_enanitos)].es_alergico = true;

	(*tope_enanitos)++;

	strcpy(enanitos[(*tope_enanitos)].nombre, "Timidon");
	enanitos[(*tope_enanitos)].estatura = 23;
	enanitos[(*tope_enanitos)].es_alergico = true;

	(*tope_enanitos)++;

	strcpy(enanitos[(*tope_enanitos)].nombre, "Feliz");
	enanitos[(*tope_enanitos)].estatura = 32;
	enanitos[(*tope_enanitos)].es_alergico = false;

	(*tope_enanitos)++;
}
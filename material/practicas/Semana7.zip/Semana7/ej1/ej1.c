#include <string.h>
#include <stdio.h>
#include <stdbool.h>

#define MAX_NOMBRE 100
#define MAX_INVITADOS 200

typedef struct invitado{
    char nombre[MAX_NOMBRE];
    bool es_familiar;
    int importancia;
    bool enviar_invitacion;
} invitado_t;

void cargar_vector(invitado_t invitados[MAX_INVITADOS], int* tope_invitados);
    
int buscar_importancia_minima(invitado_t invitados[MAX_INVITADOS], int tope_invitados){

    int pos_importancia_minima = 0;
    int importancia_minima = invitados[0].importancia;
    for (int i = 1; i < tope_invitados; i++){
        if((!invitados[i].es_familiar) && invitados[i].importancia < importancia_minima){
            importancia_minima = invitados[i].importancia;
            pos_importancia_minima = i;
        }
    }

    return pos_importancia_minima;
}

void eliminar_menor_importancia(invitado_t invitados[MAX_INVITADOS], int* tope_invitados){

    int indice = buscar_importancia_minima(invitados, *tope_invitados);
    
    invitados[indice] = invitados[(*tope_invitados)-1];
    (*tope_invitados)--;
}

void eliminar_charlotte(invitado_t invitados[MAX_INVITADOS], int tope_invitados){

    bool encontrada = false;
    int i = 0;
    while(!encontrada && i < tope_invitados){

        if(strcmp(invitados[i].nombre, "Charlotte LaBouff") == 0){
            encontrada = true;
            invitados[i].enviar_invitacion = false;
        }
        i++; //NO SE OLVIDEEEEN
    }
}

int main(){


    invitado_t invitados[MAX_INVITADOS];
    int tope_invitados = 0;
    cargar_vector(invitados, &tope_invitados);

    /*printf("TODOS LOS INVITADOS\n");
    for (int i = 0; i < tope_invitados; i++){
        printf("%s\n", invitados[i].nombre);
    }

    eliminar_menor_importancia(invitados, &tope_invitados);*/

    /*printf("DESP DE ELIMINACION\n");

    for (int i = 0; i < tope_invitados; i++){
        printf("%s\n", invitados[i].nombre);
    }*/

    printf("Nombre: %s\n", invitados[5].nombre);

    if(invitados[5].enviar_invitacion){

        printf("Charlotte esta invitada\n");
    }else{
        printf("No estas invitada luser\n");
    }

    eliminar_charlotte(invitados, tope_invitados);

    printf("Nombre: %s\n", invitados[5].nombre);

    if(invitados[5].enviar_invitacion){

        printf("Charlotte esta invitada\n");
    }else{
        printf("No estas invitada luser\n");
    }

}






























void cargar_vector(invitado_t invitados[MAX_INVITADOS], int* tope_invitados){
    strcpy(invitados[0].nombre, "Tomi Rodriguez Dala");
    invitados[0].es_familiar = false;
    invitados[0].importancia = 10;
    invitados[0].enviar_invitacion = true;

    strcpy(invitados[1].nombre, "Agus Bocaccio");
    invitados[1].es_familiar = true;
    invitados[1].importancia = 9;
    invitados[1].enviar_invitacion = true;

    strcpy(invitados[2].nombre, "Martu Rey");
    invitados[2].es_familiar = true;
    invitados[2].importancia = 8;
    invitados[2].enviar_invitacion = true;

    strcpy(invitados[3].nombre, "Nacho Destefanis");
    invitados[3].es_familiar = false;
    invitados[3].importancia = 7;
    invitados[3].enviar_invitacion = true;

    strcpy(invitados[4].nombre, "Agus Fraccaro");
    invitados[4].es_familiar = false;
    invitados[4].importancia = 2;
    invitados[4].enviar_invitacion = true;

    strcpy(invitados[5].nombre, "Charlotte LaBouff");
    invitados[5].es_familiar = false;
    invitados[5].importancia = 5;
    invitados[5].enviar_invitacion = true;

    strcpy(invitados[6].nombre, "La Peke");
    invitados[6].es_familiar = true;
    invitados[6].importancia = 6;
    invitados[6].enviar_invitacion = true;

    (*tope_invitados) = 7;
}







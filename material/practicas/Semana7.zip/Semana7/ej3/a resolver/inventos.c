#include <stdio.h>
#include <stdbool.h>

#define MAX_NOMBRE 30
#define MAX_INVENTOS 100

const char AVENTURA = 'A';
const char SERVICIO = 'S';
const char ENTRETENIMIENTO = 'E';
const char FESTIVO = 'F';
const int PUNTAJE_MAYOR = 100;
const int PUNTAJE_MENOR = 1;
const int CANT_INVENTOS = 10;
const char NEGATIVO = 'n';

typedef struct invento{

	char nombre[MAX_NOMBRE];
	char tipo;
	int puntaje;

}invento_t;

void pedir_nombre(invento_t inventos[MAX_INVENTOS], int tope_inventos){

	printf("Nombre: ");
	scanf(" %[^\n]", inventos[tope_inventos].nombre);
}

bool es_tipo_valido(char tipo){

	return(tipo == AVENTURA || tipo == ENTRETENIMIENTO || tipo == SERVICIO || tipo == FESTIVO);
}

bool es_puntaje_valido(int puntaje){

	return((puntaje >= PUNTAJE_MENOR) && (puntaje <= PUNTAJE_MAYOR));
}

void pedir_tipo(invento_t inventos[MAX_INVENTOS], int tope_inventos){

	printf("Tipo: ");
	scanf(" %c", &(inventos[tope_inventos].tipo));
	while(!es_tipo_valido(inventos[tope_inventos].tipo)){
		printf("Tipo: ");
		scanf(" %c", &(inventos[tope_inventos].tipo));
	}
}

void pedir_puntaje(invento_t inventos[MAX_INVENTOS], int tope_inventos){

	printf("Puntaje: ");
	scanf("%i", &(inventos[tope_inventos].puntaje));
	while(!es_puntaje_valido(inventos[tope_inventos].puntaje)){
		printf("Puntaje: ");
		scanf("%i", &(inventos[tope_inventos].puntaje));
	}
}

void pedir_inventos(invento_t inventos[MAX_INVENTOS], int* tope_inventos){

	bool parar = false;
	char respuesta = ' ';
	while((*tope_inventos != CANT_INVENTOS) && !parar){

		printf("Quiere ingresar un invento? [S/n]\n");
		scanf(" %c", &respuesta_phineas);
		if(respuesta == NEGATIVO){
			parar = true;
		}else{
			pedir_nombre(inventos, *tope_inventos);
			pedir_tipo(inventos, *tope_inventos);
			pedir_puntaje(inventos, *tope_inventos);
			(*tope_inventos)++;
		}
	}
}

void mostrar_inventos(invento_t inventos[MAX_INVENTOS], int tope_inventos){

	for (int i = 0; i < tope_inventos; i++){
		
		printf("INVENTO Nº%i\n", i+1);
		printf("NOMBRE: %s\n", inventos[i].nombre);
		printf("TIPO: %c\n", inventos[i].tipo);
		printf("PUNTAJE: %i\n", inventos[i].puntaje);
	}
}

int main(){

	invento_t inventos[MAX_INVENTOS];
	int tope_inventos = 0;

	pedir_inventos(inventos, &tope_inventos);

	return 0;
}
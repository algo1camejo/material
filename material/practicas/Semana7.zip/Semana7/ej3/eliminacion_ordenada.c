#include <stdio.h>

#define MAX_NUMEROS 20

void eliminar_numero(int numeros[MAX_NUMEROS], int* tope_numeros){

	for (int i = 0; i < *tope_numeros; ++i){
		if(numeros[i] == 5){
			for (int j = i; j < *tope_numeros -1; j++){
				numeros[j] = numeros[j+1];
			}
			(*tope_numeros)--;
			i--;
		}
	}
}

int main(){

	int numeros[MAX_NUMEROS];
	int tope_numeros = 10;
	numeros = {1,2,3,4,5,6,7,8,9,10};

	eliminar_numero(numeros, tope_numeros);
}
#ifndef _INVENTOS_H_
#define _INVENTOS_H_

#define MAX_NOMBRE 30
#define MAX_INVENTOS 100

typedef struct invento{

	char nombre[MAX_NOMBRE];
	char tipo;
	int puntaje;
	bool candace_aprueba;

}invento_t;

void pedir_inventos(invento_t inventos[MAX_INVENTOS], int* tope_inventos);

void mostrar_inventos(invento_t inventos[MAX_INVENTOS], int tope_inventos);

#endif //_INVENTOS_H_
#include <stdio.h>
#include <stdbool.h>
#include "inventos.h"

void ordenar_por_puntaje(invento_t inventos[MAX_INVENTOS], int tope_inventos){

	invento_t aux;
	for (int j = 1; j < tope_inventos; j++){
		for (int i = 0; i < tope_inventos - j; i++){
			if(inventos[i].puntaje > inventos[i+1].puntaje){
				aux = inventos[i];
				inventos[i] = inventos[i+1];
				inventos[i+1] = aux;
			}
		}
	}
}

void eliminar_invento(invento_t inventos[MAX_INVENTOS], int* tope_inventos, int posicion){

	for (int i = posicion; i < *tope_inventos - 1; ++i){
		inventos[i] = inventos[i+1];
	}
	*tope_inventos--;
}

void eliminar_inventos(invento_t inventos[MAX_INVENTOS], int* tope_inventos){

	for (int i = 0; i < *tope_inventos; i++){
		if(inventos[i].candace_aprueba){
			eliminar_invento(inventos, tope_inventos, i);
		}
	}
}

int main(){

	invento_t inventos[MAX_INVENTOS];
	int tope_inventos = 0;

	pedir_inventos(inventos, &tope_inventos);

	mostrar_inventos(inventos, tope_inventos);

	ordenar_por_puntaje(inventos, tope_inventos);

	eliminar_inventos(inventos, &tope_inventos);

	mostrar_inventos(inventos,tope_inventos);

	return 0;

}
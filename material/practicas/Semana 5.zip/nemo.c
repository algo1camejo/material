#include <stdio.h>
#include <stdbool.h>
#include "nemo.h"

const char VACIO = 'X';
const char NEMO = 'N';

void inicializar_matriz(char coral[MAX_FIL][MAX_COL], int tope_fila, int tope_col){

	for (int i = 0; i < tope_fila; i++){
		for (int j = 0; j < tope_col; j++){
			coral[i][j] = VACIO;
		}
	}
	coral[5][7] = NEMO;
}

bool esta_nemo(int* pos_fila, int* pos_col, char coral[MAX_FIL][MAX_COL], int tope_fila, int tope_col){

	int i = 0;
	int j = 0;
	bool encontrado = false;

	for(int i = 0; i< tope_fila; i++){
		for(int j = 0; j<tope_col; j++){
			if(coral[i][j] == NEMO){
				encontrado = true;
				(*pos_fila) = i;
				(*pos_col) = j;
			}
		}
	}
	return(encontrado);
}

void imprimir_matriz(char coral[MAX_FIL][MAX_COL], int tope_fila, int tope_col){
	for (int i = 0; i < tope_fila; i++){
		for (int j = 0; j < tope_col; j++){
			printf("%c ",coral[i][j]);
		}
		printf("\n");
	}
}
#include <stdio.h>
#include <stdbool.h>
#include "nemo.h"

int main(){

	char coral[MAX_FIL][MAX_COL];
	int tope_fila = 10;
	int tope_col = 10;
	int pos_fila = -1;
	int pos_col = -1;

	inicializar_matriz(coral, tope_fila, tope_col);
	bool nemo_presente = esta_nemo(&pos_fila, &pos_col, coral, tope_fila, tope_col);
	if(nemo_presente){
		printf("Nemo esta en la posicion %i %i\n", pos_fila, pos_col);
	}else{
		printf("Nemo se fue\n");
	}

	imprimir_matriz(coral, tope_fila, tope_col);

	return 0;
}
#ifndef __NEMO_H__
#define __NEMO_H__

#define MAX_FIL 20
#define MAX_COL 20

//PRE
//POST
void inicializar_matriz(char coral[MAX_FIL][MAX_COL], int tope_fila, int tope_col);

//PRE: La matriz tiene que estar inicializada, 
//		y sus topes inicializados y validos.
//POST: Devuelve verdadero si nemo esta en la matriz
//		y carga la posicion en la que esta
bool esta_nemo(int* pos_fila, int* pos_col, char coral[MAX_FIL][MAX_COL], int tope_fila, int tope_col);

//PRE
//POST
void imprimir_matriz(char coral[MAX_FIL][MAX_COL], int tope_fila, int tope_col);

#endif //__NEMO_H__


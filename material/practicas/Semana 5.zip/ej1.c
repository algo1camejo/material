#include <stdio.h>
#include <string.h>

#define MAX_NOMBRE 100
#define NOMBRE_INCORRECTO "Fiesta de Papa"
#define NOMBRE_CORRECTO "Papas Locas"

const int MAX_LETRAS = 20;

// Pre: 
// Pos: Carga la variable con menos de 20 caracteres.

void pedir_nombre(char nombre[MAX_NOMBRE]){

	printf("Dame el nombre de la receta wacho (delfi dice max 20 porfa)\n");
	scanf(" %[^\n]", nombre);
	while(strlen(nombre) > MAX_LETRAS){
		printf("No man, dame el nombre de la receta cortito plischu\n");
		scanf(" %[^\n]", nombre);
	}
}

// Pre: 
// Pos: ...

void chequear_nombre(char nombre[MAX_NOMBRE]){

	if(strcmp(nombre, NOMBRE_INCORRECTO) == 0){
		strcpy(nombre, NOMBRE_CORRECTO);
	}
}

int main(){

	char nombre[MAX_NOMBRE] = " ";
	pedir_nombre(nombre);
	chequear_nombre(nombre);

	printf("La receta es: %s\n", nombre);

	return 0;
}
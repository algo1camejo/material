#include <stdio.h>

#define MAX_CANTIDAD 50

//PRE: Tope mayor o igual a 0. Valores mayores o iguales a 0
//POST: Devuelve la suma total de los objetos mensuales
int suma_mensual_objetos(int objetos_semanales[MAX_CANTIDAD],int tope_objetos){
    int suma = 0;
    for(int i=0; i<tope_objetos;i++){
        suma = suma + objetos_semanales[i]; 
    }
    return suma;
}

//Pre: valores distintos entre si, tope mayor o igual a 0
//Post: Devuelve el valor maximo del vector y su posicion.
void buscar_maximo(int objetos_semanales[MAX_CANTIDAD],int tope,int* posicion_max,int* objeto_maximo){
    (*posicion_max) = 0;
    (*objeto_maximo) = objetos_semanales[0];
    for(int i =1; i<tope;i++){
        if(objetos_semanales[i] > (*objeto_maximo)){
            (*objeto_maximo) = objetos_semanales[i];
            (*posicion_max) = i;
        }
    }
} 

int main(){
    
    int objetos_semanales[MAX_CANTIDAD]; 
    int tope_objetos = 0;

    //int objetos_semanales_2[MAX_CANTIDAD] = {5,10,34,66};
    //int tope_objetos2 = 4;

    objetos_semanales[tope_objetos] = 5;
    tope_objetos++;
    objetos_semanales[tope_objetos] = 10;
    tope_objetos++;
    objetos_semanales[tope_objetos] = 23;
    tope_objetos++;
    objetos_semanales[tope_objetos] = 8;
    tope_objetos++;
    
    for(int i=0; i<tope_objetos;i++){
        //printf("La posicion: %i. Su elemento: %i\n",i,objetos_semanales[i]);
    }

    //int suma_objetos = suma_mensual_objetos(objetos_semanales,tope_objetos);
    //printf("%i\n",suma_objetos);

    int posicion_max;
    int objeto_maximo;
    buscar_maximo(objetos_semanales,tope_objetos,&posicion_max, &objeto_maximo);
    printf("%i\n",posicion_max);
    printf("%i\n",objeto_maximo);


    return 0;
}



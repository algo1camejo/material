#include <stdio.h>
#include <stdbool.h>

#define MAX_INTENSIDADES 100

const char PREOCUPANTE = 'P';
const char REGULAR = 'R';
const char EXCELENTE = 'E';

const int MIN_PREOCUPANTE = 4;

// PRE: Recibe un vector inicializado con numeros
// entre 1 y 10 inclusive junto su tope, y otro vector
//  con su tope inicializado en 0.
// POST: Carga el segundo vector traduciendo
//  las situaciones correspondientes
//(PREOCUPANTE, REGULAR, EXCELENTE)
void cargar_situaciones(int intensidades[MAX_INTENSIDADES], int tope_intensidades, char situaciones[MAX_INTENSIDADES], int *tope_situaciones)
{
    for (int i = 0; i < tope_intensidades; i++)
    {
        if (intensidades[i] >= 1 && intensidades[i] <= 3)
        {
            situaciones[*tope_situaciones] = PREOCUPANTE;
        }
        else if (intensidades[i] >= 4 && intensidades[i] <= 7)
        {
            situaciones[*tope_situaciones] = REGULAR;
        }
        else
        {
            situaciones[*tope_situaciones] = EXCELENTE;
        }
        (*tope_situaciones)++;
    }
}

bool debe_preocuparse(char situaciones[MAX_INTENSIDADES], int tope_situaciones){
    int contador = 0;
    int i = 0;
    while(i<tope_situaciones && contador< MIN_PREOCUPANTE){
        if(situaciones[i] == PREOCUPANTE){
            contador++;
        }
        i++;
    }
    return(contador>=MIN_PREOCUPANTE);
}

int main()
{

    int intensidades[MAX_INTENSIDADES] = {2, 4, 5, 7, 1, 3, 8};
    int tope_intensidades = 7;

    char situaciones[MAX_INTENSIDADES];
    int tope_situaciones = 0;
    cargar_situaciones(intensidades, tope_intensidades, situaciones, &tope_situaciones);

    // for (int i = 0; i < tope_situaciones; i++)
    // {
    //     printf("%i ", intensidades[i]);
    //     printf("%c\n", situaciones[i]);
    // }

    if(debe_preocuparse(situaciones, tope_situaciones)){
        printf("Se preocupa");
    }
    else{
        printf("ya nos vamos");
    }

    return 0;
}
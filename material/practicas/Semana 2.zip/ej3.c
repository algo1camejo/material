#include <stdio.h>

const int NAFTA_MINIMA = 30;
const int CANTIDAD_VUELTAS = 3;
const char PRESION_BAJA = 'B';
const char PRESION_ALTA = 'A';
const char PRESION_NORMAL = 'N';
const char VISION_LIMPIA = 'L';
const char VISION_SUCIA = 'S';

int main(){
	
	char presion = ' ';
	char vision = ' ' ;
	int litros_nafta = -1;

	for(int vueltas = 0; vueltas < CANTIDAD_VUELTAS; vueltas++){

		printf("Rayo decime la presion rey: ");
		scanf(" %c", &presion);
		printf("Rayo decime como anda la vision: ");
		scanf(" %c", &vision);
		printf("Rayo cuanta nafta te queda: ");
		scanf("%i", &litros_nafta);

		if(((presion != PRESION_NORMAL)&& vision == VISION_SUCIA)||(litros_nafta <= NAFTA_MINIMA)){
			printf("A LOS PITS \n");
		}else{
			printf("Kuchau\n");

		}
	}


	return 0;
}
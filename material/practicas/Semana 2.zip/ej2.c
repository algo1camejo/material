#include <stdio.h>

const int DALMATAS_TOTAL = 101;
const int DALMATAS_INICIAL = 1;
const int DALMATAS_RAPTADOS = 0;

int main(){
	/*2.1
	for(int dalmatas = DALMATAS_INICIAL;dalmatas <= DALMATAS_TOTAL;dalmatas++){
		printf("Dalmata numero %i\n",dalmatas);
	}
	*/
	/*2.2
	int total_dalmatas = -1;
	printf("Cuantos salen a pasear hoy?\n");
	scanf("%i",&total_dalmatas);

	int contador = DALMATAS_INICIAL;
	while(contador <= total_dalmatas){
		printf("Dalmata numero %i\n",contador);
		contador++;
	}
	*/

	//2.3

	int total_dalmatas = -1;
	printf("Cuantos salen a pasear hoy?\n");
	scanf("%i",&total_dalmatas);
	int contador = total_dalmatas;
	do{
		printf("Faltan %i dalmatas\n",contador);
		contador--;
	}while(contador >= DALMATAS_RAPTADOS);


	return 0;
}
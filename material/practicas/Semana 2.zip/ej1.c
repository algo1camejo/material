#include <stdio.h>

const char PELIGRO = 'P';
const char BUENA = 'B';
const char INDEFINIDO = 'I';

const int MINIMO = 0;
const int MAXIMO = 10;
const int COMESTIBLE_MAX = 5;

int main(){
	/*1.1
	char galleta = 'I';

	if(galleta == PELIGRO){
		printf("No comer, es peligroso!!!\n");
	} else if(galleta == BUENA){
		printf("Bon appetit!\n");
	} else if(galleta == INDEFINIDO){
		printf("Comer bajo tu propio riesgo\n");
	}
	*/

	
	int masita = -1;
	int botella = -1;
	
	printf("Tengo hambre. Me puedo comer la masita?\n");
	printf("Que pesada Alicia, que peligrosidad tiene? Ingrese un numero entre 0 y 10 inclusive\n");

	scanf("%i",&masita);

	printf("Tengo sedddd. Me puedo tomar el fernecito?\n");
	printf("que manija Alicia, que peligrosidad tiene? Ingrese un numero entre 0 y 10 inclusive\n");

	scanf("%i",&botella);



//&& --> and
//|| --> or

	if((MINIMO <= masita && masita <= COMESTIBLE_MAX) && (botella >= MINIMO && botella <= COMESTIBLE_MAX)){
		printf("si se puede\n");
	} else if((masita > COMESTIBLE_MAX && masita <= MAXIMO) || (botella > COMESTIBLE_MAX && botella <= MAXIMO)){
		printf("hace ayuno mejor\n");
	} else{
		printf("vanesaaaa no nos desconozcamos\n");
	}


	return 0;
}
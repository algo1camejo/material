#include <stdio.h>
#include <string.h>

#define MAX_NOMBRE 50
#define MAX_GUSTO 40
#define ESCRITURA "%s;%s;%s\n"
#define LECTURA "%[^;];%[^;];%[^\n]\n"

typedef struct amigo{
	char nombre[MAX_NOMBRE];
	char gusto_1[MAX_GUSTO];
	char gusto_2[MAX_GUSTO];
}amigo_t;

int main(int argc, char* argv[]){

	if(strcmp(argv[1], "agregar") == 0){
		if(argc == 5){
			FILE* archivo_postres = fopen("postres.csv", "a");
			if(archivo_postres == NULL){
				perror("NO se pudo abrir el archivo :(\n");
				return -1;
			}
			fprintf(archivo_postres, ESCRITURA, argv[2], argv[3], argv[4]);
			fclose(archivo_postres);
		}else{
			printf("Che me falta algun dato.. raaro\n");
		}
	}else if(strcmp(argv[1], "eliminar") == 0){
		if(argc == 3){
			FILE* archivo_postres = fopen("postres.csv", "r");
			if(archivo_postres == NULL){
				perror("NO se pudo abrir el archivo :(\n");
				return -1;
			}
			FILE* archivo_aux = fopen("aux.csv", "w");
			if(archivo_aux == NULL){
				perror("NO se pudo abrir el archivo :(\n");
				fclose(archivo_postres);
				return -1;
			}
			amigo_t amigo;
			do{
				fscanf(archivo_postres, LECTURA, amigo.nombre, amigo.gusto_1, amigo.gusto_2);
				if(strcmp(argv[2], amigo.gusto_1) != 0 && strcmp(argv[2], amigo.gusto_2) != 0){
					fprintf(archivo_aux, ESCRITURA, amigo.nombre, amigo.gusto_1, amigo.gusto_2);
				}
			}while(!feof(archivo_postres));
			fclose(archivo_postres);
			fclose(archivo_aux);
			rename("aux.csv", "postres.csv");
		}else{
			printf("Che me falta algun dato.. raaro\n");
		}
	}else{
		printf("Che me mandaste mal la data\n");
	}


	return 0;

}
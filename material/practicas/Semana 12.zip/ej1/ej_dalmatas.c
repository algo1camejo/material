#include<stdio.h>
#include<stdbool.h>

#define MAX_NOMBRE 75
#define MAX_CANCION 75

typedef struct dalmanta {
  char nombre[MAX_NOMBRE];
  char cancion_favorita[MAX_CANCION];
  int cantidad_manchas;
  bool ruidoso;
} dalmata_t;


int main(){
    FILE* archivo_dalmatas = fopen("dalmatas.csv", "r");
    if(archivo_dalmatas == NULL){
        perror("No se pudo abrir el archivo dalmatas.");
        return -1;
    }

    FILE* archivo_ruidosos = fopen("ruidosos.csv", "w");
    if(archivo_ruidosos == NULL){
        perror("No se pudo abrir el archivo ruidosos.");
        fclose(archivo_dalmatas);
        return -1;
    }

    FILE* archivo_silenciosos = fopen("silenciosos.csv", "w");
    if(archivo_silenciosos == NULL){
        perror("No se pudo abrir el archivo silenciosos.");
        fclose(archivo_dalmatas);
        fclose(archivo_ruidosos);
        return -1;
    }

    dalmata_t dalmata_leido;
    char ruidoso;

    fscanf(archivo_dalmatas, "%[^;];%[^;];%i;%c\n", dalmata_leido.nombre, dalmata_leido.cancion_favorita, &(dalmata_leido.cantidad_manchas), &ruidoso);

    while(!feof(archivo_dalmatas)){
        if(ruidoso == 'S'){
            dalmata_leido.ruidoso = true;
        } else {
            dalmata_leido.ruidoso = false;
        }

        if(dalmata_leido.ruidoso){
            fprintf(archivo_ruidosos, "%s;%s;%i;%c\n", dalmata_leido.nombre, dalmata_leido.cancion_favorita, dalmata_leido.cantidad_manchas, ruidoso);
        } else {
            fprintf(archivo_silenciosos, "%s;%s;%i;%c\n", dalmata_leido.nombre, dalmata_leido.cancion_favorita, dalmata_leido.cantidad_manchas, ruidoso);
        }

        fscanf(archivo_dalmatas, "%[^;];%[^;];%i;%c\n", dalmata_leido.nombre, dalmata_leido.cancion_favorita, &(dalmata_leido.cantidad_manchas), &ruidoso);
    }

    fclose(archivo_silenciosos);
    fclose(archivo_ruidosos);
    fclose(archivo_dalmatas);

    return 0;
}


#include <stdio.h>
#include <string.h>

#define MAX_NOMBRE 50
#define MAX_GUSTO 40
#define LECTURA "%[^;];%[^;];%[^\n]\n"
#define ESCRITURA "%s;%s;%s\n"

typedef struct amigos{
	char nombre[MAX_NOMBRE];
	char gusto_1[MAX_GUSTO];
	char gusto_2[MAX_GUSTO];
}amigo_t;

void agregar_amigo(FILE* archivo_postres, char nombre[MAX_NOMBRE], char gusto_1[MAX_GUSTO], char gusto_2[MAX_GUSTO]){
	fprintf(archivo_postres, ESCRITURA , nombre, gusto_1, gusto_2);
}

void eliminar_gusto(FILE* archivo_postres, FILE* archivo_aux, char gusto_ingresado[MAX_GUSTO]){
	amigo_t amigo;
	fscanf(archivo_postres, LECTURA, amigo.nombre, amigo.gusto_1, amigo.gusto_2);
	while(!feof(archivo_postres)){
		if(strcmp(amigo.gusto_1, gusto_ingresado) != 0 && strcmp(amigo.gusto_2, gusto_ingresado) != 0){
			fprintf(archivo_aux, ESCRITURA , amigo.nombre, amigo.gusto_1, amigo.gusto_2);
		}
		fscanf(archivo_postres, LECTURA, amigo.nombre, amigo.gusto_1, amigo.gusto_2);
	}
}

int main(int argc, char* argv[]){

	if(argc > 1){
		if(strcmp(argv[1], "agregar") == 0){
			if(argc == 5){
				FILE* archivo_postres = fopen("postres.csv", "a");
				if(!archivo_postres){
					perror("El archivo no se pudo abrir\n");
					return -1;
				}
				agregar_amigo(archivo_postres,argv[2], argv[3], argv[4]);
				fclose(archivo_postres);
			}else{
				printf("El comando para agregar un amigo es incorrecto.\n");
			}
		}else if(strcmp(argv[1], "eliminar") == 0){
			if(argc == 3){
				FILE* archivo_postres = fopen("postres.csv", "r");
				if(!archivo_postres){
				perror("El archivo no se pudo abrir\n");
				return -1;
				}
				FILE* archivo_aux = fopen("temp.csv", "w");
				if(!archivo_aux){
					perror("El archivo no se pudo abrir\n");
					fclose(archivo_postres);
					return -1;
				}
				eliminar_gusto(archivo_postres, archivo_aux, argv[2]);
				fclose(archivo_aux);
				fclose(archivo_postres);
				rename("temp.csv", "postres.csv");
			}else{
				printf("El comando para eliminar un amigo es incorrecto.\n");
			}
		}
	}else{
		printf("La cantidad de comandos ingresados es incorrecta.\n");
	}
	
	return 0;
}
#include <stdio.h>

unsigned long factorial_iter(unsigned n) {
	unsigned long acumulador = 1;

	for (unsigned i = 1; i <= n; i++) {
		acumulador = acumulador * i;
	}

	return acumulador;
}

// Si n = 1 => n! = 1
// Si n != 1 => n! = n*(n-1)!
unsigned long factorial_rec(unsigned n) {
	if (n == 1) {
		return 1;
	}

	return n * factorial_rec(n-1);
}

int main() {
	unsigned n = 5;
	printf("%u! = %lu\n", n, factorial_iter(n));
	printf("%u! = %lu\n", n, factorial_rec(n));

	return 0;
}
#include <stdio.h>

#define MAX 10

int posicion_a_insertar(int vector[MAX], int tope, int numero) {
	int i = 0;
	while (i < tope && vector[i] < numero) {
		i++;
	}

	return i;
}

void insertar(int vector[MAX], int* tope, int numero) {
	if (*tope == MAX) {
		printf("No hay más lugar en el vector!\n");
		return;
	}

	int posicion = posicion_a_insertar(vector, *tope, numero);

	for (int i = *tope; i > posicion; i--) {
		vector[i] = vector[i-1];
	}

	vector[posicion] = numero;
	(*tope)++;
}

int main() {
	int vector[MAX];
	int tope;
	
	vector[0] = 3;
	vector[1] = 6;
	vector[2] = 9;
	vector[3] = 13;
	tope = 4;

	insertar(vector, &tope, 7);

	for (int i = 0; i < tope; i++) {
		printf("%i ", vector[i]);
	}
	printf("\n");
}
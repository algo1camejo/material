#include <stdio.h>

int saltos(int vector[6], int tope, int indice) {
	if (indice == 0) {
		return 0;
	}

	return 1 + saltos(vector, tope, vector[indice]);
}

int main() {
	int vector[6] = {5, 3, 1, 4, 0, 2};
	int tope = 6;

	int inicio = 2;
	printf("Saltos necesarios para llegar al índice 0 "
		   "desde la posicion %i: %i\n", inicio, saltos(vector, tope, inicio));

	return 0;
}

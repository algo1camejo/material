#include <stdio.h>
#include <string.h>

//const int MAX_NOMBRE = 20;
#define MAX_NOMBRE 20

int main(){

	// String: Hola! Llegué :)
	// -> \0
	char vector[MAX_NOMBRE] = "MANU";
	// vector -> MANU

	//vector = "TOMI"; // No puedo :(
	printf("%s\n", vector);
	strcpy(vector, "Tomi gato");
	printf("%s\n", vector);
	
	vector[1] = 'i';
	vector[6] = 'i';
	vector[8] = 'i';
	printf("%s\n", vector);


	int largo = strlen(vector);
	printf("el string mide: %i\n", largo);

	// comparar strings!
	char un_colab[MAX_NOMBRE] = "Nico";
	char otro_colab[MAX_NOMBRE] = "Nico";

 	//strcmp(un_colab, otro_colab)
 	//-> 0 si son iguales
 	//-> > 0 si izq es mayor que der
 	//-> < 0 si izq es menor que der
	if (strcmp(un_colab, otro_colab) == 0){
		printf("Son iguales\n");
	} else {
		printf("Son distintos\n");
	}


	char colab_3[MAX_NOMBRE] = "Manu";
	strcat(colab_3, " ");
	strcat(colab_3, "Bilbao");
	printf("%s\n", colab_3);



	return 0;
}
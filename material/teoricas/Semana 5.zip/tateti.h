#ifndef __TATETI_H__
#define __TATETI_H__

#define MAX_FILAS 3
#define MAX_COLUMNAS 3

// Pre: -
// Pos: Inicializa el tablero con espacios vacios.
void inicializar_tablero(char tablero[MAX_FILAS][MAX_COLUMNAS]);

// Pre: -
// Pos: Pide fila y columna y los guarda.
void pedir_fila_columna(int* fila, int* columna);

// Pre: El tablero está inicializado.
// Pos: Imprime el tablero por pantalla.
void mostrar_tablero(char tablero[MAX_FILAS][MAX_COLUMNAS]);

// Pre: fila debe ser >= 0 y < MAX_FILAS.
// 		columna debe ser >= 0 y < MAX_COLUMNAS.
// 		jugador debe ser X o O.
// Pos: Inserta la jugada en el tablero, en la posición [fila, columna]
void insertar_jugada(char tablero[MAX_FILAS][MAX_COLUMNAS], int fila, int columna, char jugador);

#endif // __TATETI_H__
#include<stdio.h>
#include "tateti.h"

#define MAX_FILAS 3
#define MAX_COLUMNAS 3

const char CRUZ = 'X';
const char CIRCULO = 'O';

int main() {
	char tablero[MAX_FILAS][MAX_COLUMNAS];

	inicializar_tablero(tablero);

	int fila;
	int columna;

	pedir_fila_columna(&fila, &columna);

	tablero[fila][columna] = CRUZ;

	pedir_fila_columna(&fila, &columna);

	tablero[fila][columna] = CIRCULO;

	mostrar_tablero(tablero);

	return 0;
}
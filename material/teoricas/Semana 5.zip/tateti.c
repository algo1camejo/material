#include "tateti.h"
#include <stdio.h>

const char ESPACIO_VACIO = ' ';

void inicializar_tablero(char tablero[MAX_FILAS][MAX_COLUMNAS]) {
	for (int f = 0; f < MAX_FILAS; f++) {
		for (int c = 0; c < MAX_COLUMNAS; c++) {
			tablero[f][c] = ESPACIO_VACIO;
		}
	}
}

void mostrar_tablero(char tablero[MAX_FILAS][MAX_COLUMNAS]) {
	for (int f = 0; f < MAX_FILAS; f++) {
		for (int c = 0; c < MAX_COLUMNAS; c++) {
			printf("|%c|", tablero[f][c]);
		}
		printf("\n");
	}
}

void pedir_fila_columna(int* fila, int* columna) {
	printf("Ingrese una fila: ");
	scanf("%i", fila);
	printf("Ingrese una columna: ");
	scanf("%i", columna);
}

void insertar_jugada(char tablero[MAX_FILAS][MAX_COLUMNAS], int fila, int columna, char jugador) {
	tablero[fila][columna] = jugador;
}
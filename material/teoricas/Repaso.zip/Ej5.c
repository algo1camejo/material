#include <stdio.h>
#include <string.h>

#define MAX_ORACION 100
#define MAX_PALABRA 20

const int NO_ENCONTRADO = -1;

// Pre: Los parámetros son strings de C.
// Pos: Devuelve la primera posicion de palabra dentro de oracion.
// 		O NO_ENCONTRADO si no se encuentra.
int posicion_palabra(char oracion[MAX_ORACION], char palabra[MAX_PALABRA]) {
	int largo_oracion = strlen(oracion);
	int largo_palabra = strlen(palabra);
	int i = 0;
	int posicion = NO_ENCONTRADO;

	// int vector[] = {4, 3, 6, 7};
	// vector+1 === &(vector[1])
	// "Oye Tablón tu mamá te llama"
	//	^----- oracion
	//	 ^---- oracion+1
	//	  ^--- oracion+2
	// " mam"
	while (i < largo_oracion) {
		if (strncmp(&(oracion[i]), palabra, largo_palabra) == 0) {
			posicion = i;
		}
		i++;
	}

	return posicion;
}

int posicion_palabra2(char oracion[MAX_ORACION], char palabra[MAX_PALABRA]) {
	// oracion: 0x0004b3cd2
	char* oracion_desde_palabra = strstr(oracion, palabra); // 0x0004b3cd6

	if (oracion_desde_palabra == NULL) {
		return NO_ENCONTRADO;
	}

	return (int)oracion_desde_palabra - (int)oracion;
}

int main() {
	printf("%i\n", posicion_palabra("Oye Tablon tu mama te llama", "Tablon"));
	// char* vector = "Hola, como estas?";
	// printf("%s\n", &(vector[1]));
}
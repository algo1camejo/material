// Pre: fil y col < MAX_TUERCAS y >= 0. nueva_tuerca >= 1.
// Pos: Guarda en la matriz caja, posicion [fil][col], el valor nueva_tuerca.
// 		Sobreescribe el valor anterior.
bool guardar_tuerca(int caja[MAX_TUERCAS][MAX_TUERCAS], int fil, int col, int nueva_tuerca) {
	caja[fil][col] = nueva_tuerca;

	bool hay_tuerca_mayor = false;

	int i;
	if (fil-1 >= 0) {
		i = fil-1;
	} else {
		i = fil;
	}

	while (!hay_tuerca_mayor && i <= fil+1 && i < MAX_TUERCAS) {
		/*int j;
		if (col > 0) {
			j = col-1;
		} else {
			j = col;
		}*/
		int j = col-1;
		while(!hay_tuerca_mayor && j <= col+1 && j < MAX_TUERCAS) {
			if (j >= 0 && caja[i][j] >= nueva_tuerca && !(i == fil && j == col)) {
				hay_tuerca_mayor = true;
			}
			j++;
		}
		i++;
	}

	return !hay_tuerca_mayor;
}
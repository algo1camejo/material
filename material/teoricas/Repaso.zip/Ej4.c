#include <stdio.h>

#define MAX_BANANAS 30
const int MADUREZ_MAXIMA = 7;
const int BANANAS_BUSCADAS = 3;
const int NO_ENCONTRADO = -1;

// Pre: 0 <= tope <= MAX_BANANAS. 0 <= bananas_aceptadas < BANANAS_BUSCADAS.
// 		0 <= pos_actual < tope.
// Pos: Devuelve la posición de la banana aceptada #BANANAS_BUSCADAS.
int posicion_banana_rec(int bananas[MAX_BANANAS], int tope, int pos_actual, int bananas_aceptadas) {
	if (pos_actual >= tope) {
		return NO_ENCONTRADO;
	}

	/*
	// Otra forma, en lugar de las líneas [25;31]
	if (bananas[pos_actual] < MADUREZ_MAXIMA) {
		bananas_aceptadas++;
	}

	if (bananas_aceptadas == BANANAS_BUSCADAS) {
		return pos_actual;
	}
	*/

	if (bananas_aceptadas == BANANAS_BUSCADAS-1 && bananas[pos_actual] < MADUREZ_MAXIMA) {
		return pos_actual;
	}

	if (bananas[pos_actual] < MADUREZ_MAXIMA) {
		bananas_aceptadas++;
	}
	
	return posicion_banana_rec(bananas, tope, pos_actual+1, bananas_aceptadas);
}

// Pre: 0 <= tope <= MAX_BANANAS.
// Pos: Devuelve la posición de la banana aceptada #BANANAS_BUSCADAS.
int posicion_banana(int bananas[MAX_BANANAS], int tope) {
	return posicion_banana_rec(bananas, tope, 0, 0);
}

int main() {
	int bananas[MAX_BANANAS] = {6, 7, 8, 7, 4, 6, 5, 7, 8, 8};
	int tope_bananas = 10;
	int posicion = posicion_banana(bananas, tope_bananas);
	printf("Posicion: %i\n", posicion);
}
// Faltan pre y pos. Falta chequear en caso de empate la peligrosidad

#define MAX_NOMBRE 25
#define MAX_ENEMIGOS

typedef struct enemigo {
	char nombre[MAX_NOMBRE];
	int miedo_ocasionado;
	int peligrosidad;
} enemigo_t;

int posicion_mas_aterrador_menos_peligroso(enemigo_t enemigos[MAX_ENEMIGOS], int tope) {
	int i = 0;
	int mas_miedo = 0;
	
	while(i<tope) {
		if(enemigos[i].miedo_ocasionado > enemigos[mas_miedo].miedo_ocasionado) {
			mas_miedo = i;
		}
		i++;
	}

	return mas_miedo;
}
#include <string.h>

#define MAX_NOMBRE 50
#define MAX_TICKETS 50

typedef struct fecha {
	int dia;
	int mes;
	int anio;
} fecha_t;

typedef struct ticket {
	char nombre[MAX_NOMBRE];
	fecha_t fecha_pedido;
	int fecha_cosecha_alma; // En unix timestamp
	char estado; // 'C': cocechado, 'N': No cocechado, 'P': En proceso.
	int numero_universo;
	int id_cosechador;
	char especie[MAX_NOMBRE];
	char rubro; // 'A': Adminitrativo, 'R': RRHH, 'C': Oficina de cosecha de almas
	int edad;
} ticket_t;

// Pre: El vector tickets está ordenado por nombre. 0 <= tope < MAX_TICKETS.
// 		ticket_a_insertar tiene nombre.
// Pos: Inserta el elemento ticket_a_insertar en tickets de forma ordenada.
// 		Incrementa el tope en 1.
void insertar_ticket(ticket_t tickets[MAX_TICKETS], int* tope, ticket_t ticket_a_insertar) {
	// Paso 1: Buscar posicion a insertar
	int posicion_a_insertar = 0;
	while (posicion_a_insertar < *tope && strcmp(tickets[posicion_a_insertar].nombre, ticket_a_insertar.nombre) < 0) {
		posicion_a_insertar++;
	}

	// Paso 2: Muevo todos los elementos desde la pos. a insertar a la derecha
	for (int i = *tope; i > posicion_a_insertar; i--) {
		tickets[i] = tickets[i-1];
	}

	// Paso 3: Insertar el valor e incrementar el tope
	tickets[posicion_a_insertar] = ticket_a_insertar;
	(*tope)++;
}
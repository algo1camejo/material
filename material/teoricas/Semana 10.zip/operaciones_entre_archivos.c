#include <stdio.h>

#define MAX_NUMEROS 50

void mostrar_vector(int vector[MAX_NUMEROS], int tope){
	for (int i = 0; i < count; i++){
		printf("%i\n", vector[i]);
	}
}

int main(){

	int a[MAX_NUMEROS] = 
		{2, 4, 7, 8, 14, 18, 23};
	int tope_a = 7;

	int b[MAX_NUMEROS] = 
		{6, 9, 14, 15, 23, 25, 28, 29};
	int tope_b = 8;

	int aub[MAX_NUMEROS];
	int tope_aub = 0;
	int i = 0, j = 0;

	// UNION
	while (i < tope_a && j < tope_b){
		if (a[i] < b[j]){
			aub[tope_aub] = a[i];
			tope_aub++;
			i++;
		} else if (a[i] > b[j]){
			aub[tope_aub] = b[j];
			tope_aub++;
			j++;
		} else {
			aub[tope_aub] = a[i];
			tope_aub++;
			i++;
			j++;
		}

	}

	for (; i < tope_a; i++){
		aub[tope_aub] = a[i];
		tope_aub++;
	}

	for (; j < tope_b; j++){
		aub[tope_aub] = b[j];
		tope_aub++;
	}

	// INTERSECCION
	int anb[MAX_NUMEROS];
	int tope_anb = 0;
	i = 0;
	j = 0;

	while (i < tope_a && j < tope_b){
		if (a[i] < b[j]){
			i++;
		} else if (a[i] > b[j]){
			j++;
		} else {
			anb[tope_anb] = a[i];
			tope_anb++;
			i++;
			j++;
		}

	}

	// for (; i < tope_a; i++){
	// 	anb[tope_anb] = a[i];
	// 	tope_anb++;
	// }

	// for (; j < tope_b; j++){
	// 	anb[tope_anb] = b[j];
	// 	tope_aub++;
	// }

	// DIFERENCIA SIMETRICA
	int adb[MAX_NUMEROS];
	int tope_adb = 0;
	i = 0;
	j = 0;

	while (i < tope_a && j < tope_b){
		if (a[i] < b[j]){
			adb[tope_adb] = a[i];
			tope_adb++;
			i++;
		} else if (a[i] > b[j]){
			adb[tope_adb] = b[j];
			tope_adb++;
			j++;
		} else {
			i++;
			j++;
		}

	}

	for (; i < tope_a; i++){
		adb[tope_adb] = a[i];
		tope_adb++;
	}

	for (; j < tope_b; j++){
		adb[tope_adb] = b[j];
		tope_adb++;
	}



	mostrar_vector();
	return 0;
}
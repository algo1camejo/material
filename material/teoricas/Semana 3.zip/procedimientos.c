#include <stdio.h>

void potencia() {
	int potencia = otra_potencia();

	printf("La potencia es: %i\n", potencia);
}

int otra_potencia();

int main() {
	potencia();

	int mi_potencia = otra_potencia();

	printf("Mi potencia es %i\n", mi_potencia);

	return 0;
}

int otra_potencia() {
	int base;
	printf("Base: ");
	scanf("%i", &base);

	int exponente;
	printf("Exponente: ");
	scanf("%i", &exponente);

	int potencia = 1;
	for (int i = exponente; i > 0; i--) {
		potencia = base * potencia;
	}

	return potencia;
}
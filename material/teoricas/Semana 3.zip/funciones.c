#include <stdio.h>

const int INFINITO = 1000500000;

int suma_fea(int sumando1, int sumando2){
	int resultado = sumando1 + sumando2;
	return resultado;
}

int suma_linda(int sumando1, int sumando2){
	return sumando1 + sumando2;
}

/*
 * Pre: divisor diferente de 0.
 */
int division(int dividendo,int divisor){
	if(divisor != 0){
		return dividendo/divisor;
	}
	return INFINITO;
}






int main(){
	
	int numero1 = 18;
	int numero2 = 0;
	int resultado = suma_linda(numero1,numero2);
	printf("El resultado es %i\n",resultado);

	resultado = division(numero1,numero2);
	printf("El resultado es %i\n",resultado);
	return 0;
}
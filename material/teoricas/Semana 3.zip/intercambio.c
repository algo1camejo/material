#include <stdio.h>

void intercambiar(char* ref_inicial_1, char* ref_inicial_2){
	char inicial_aux;
	inicial_aux = (*ref_inicial_1);
	(*ref_inicial_1) = (*ref_inicial_2);
	(*ref_inicial_2) = inicial_aux;
}


int main(){
	
	char inicial_manu = 'S';
	char inicial_sol = 'M';

	printf("Antes: Inicial Manu %c, inicial Sol %c\n",inicial_manu,inicial_sol);
	intercambiar(&inicial_manu,&inicial_sol);
	printf("Despues: Inicial Manu %c, inicial Sol %c\n",inicial_manu,inicial_sol);
	

	return 0;
}
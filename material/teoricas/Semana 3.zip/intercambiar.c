

const int CARTA_VER_TOMI_1 = 7;
const int CARTA_VER_TOMI_2 = 8;

const int CARTA_VER_MANU_1 = 9;
const int CARTA_VER_MANU_2 = 10;

const int CARTA_INTER_1 = 11;
const int CARTA_INTER_2 = 12;

const int CARTA_INTER_Y_VER = 13;


void intercambiar(int* un_numero, int* otro_numero){
    int aux = *un_numero;

    *un_numero = *otro_numero;
    *otro_numero = aux;
}

void pedir_cartas(int* carta_tomi, int* carta_manu){
	printf("Sol, ingrese la carta de Tomi:");
	scanf("%i", carta_tomi);

	printf("Sol, ingrese la carta de Manu:");
	scanf("%i", carta_manu);

}

void pedir_carta_mazo(int* carta_mazo){
	printf("Tomi, ingrese la carta que sacó del mazo:");
	scanf("%i", carta_mazo);
}

int main(){
	int carta_tomi = 0;
	int carta_manu = 0;
	int carta_mazo = 0;

	pedir_cartas(&carta_tomi, &carta_manu);
	pedir_carta_mazo(&carta_mazo);


	if(carta_mazo == 11 || carta_mazo == 12){
		intercambiar(&carta_tomi, &carta_manu);
	}

	printf("La carta de Tomi es: %i", carta_tomi);
	printf("La carta de Manu es: %i", carta_manu);
	

	return 0;
}
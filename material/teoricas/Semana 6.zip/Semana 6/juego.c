#include <stdlib.h>
#include <time.h>
#include "yugio.h"

int main() {
    srand(time(NULL));

    monstro_t charly, messi;

    inicializar_monstro(&messi);
    inicializar_monstro(&charly);

    mostrar_monstro(messi);
    mostrar_monstro(charly);    

    curar(&(messi.vida));

    mostrar_monstro(messi);
    return 0;
}
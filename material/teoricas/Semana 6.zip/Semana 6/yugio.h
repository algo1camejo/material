#ifndef __YUGIO_H__
#define __YUGIO_H__

#include <stdbool.h>

#define MAX_NOMBRE 50
#define MAX_EQUIPO 50

typedef struct equipa {
    int plus_ataque;
    int plus_defensa;
} equipa_t;

typedef struct acompaniero {
    char nombre[MAX_NOMBRE];
    char tipo;
} acompaniero_t;

typedef struct monstro {
    char nombre[MAX_NOMBRE];
    int vida;
    int ataque;
    int defensa;
    bool es_magico;
    acompaniero_t acompaniero;
    equipa_t equipo[MAX_EQUIPO];
    int tope_equipo;
    int equipo_en_uso;
} monstro_t;

/*
 * Pre: 
 * Post:
 */
void inicializar_monstro(monstro_t* monstro);

/*
 * Pre: 
 * Post:
 */
void curar(int* vida);

/*
 * Pre: 
 * Post:
 */
void mostrar_monstro(monstro_t monstro);

/*
 * Pre: 
 * Post:
 */
void atacar(monstro_t atacante, monstro_t* atacado);


#endif /* __YUGIO_H__ */
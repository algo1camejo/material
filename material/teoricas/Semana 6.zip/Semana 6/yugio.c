#include "yugio.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

const int VIDA_INICIAL = 100;
const char TIERRA = 'T';

void inicializar_monstro(monstro_t* monstro){

    // printf("Vida: \n");
    // scanf("%i", &((*monstro).vida));

    printf("Nombre: \n");
    scanf("%s", (*monstro).nombre);

    (*monstro).vida = VIDA_INICIAL;
    monstro->vida = VIDA_INICIAL;

    /* son equivalentes */
    // (*_)._
    // _->_

    (*monstro).ataque = (rand() % 91) + 10;
    (*monstro).defensa = (rand() % 91) + 10;
    (*monstro).es_magico = !(rand() % 10);

    (*monstro).acompaniero.tipo = TIERRA;
    //monstro->acompaniero.tipo = TIERRA;
    (*monstro).tope_equipo = 0;
    (*monstro).equipo[0].plus_ataque = (rand() % 11);
    (*monstro).equipo[0].plus_defensa = (rand() % 11);
    ((*monstro).tope_equipo)++;

    (*monstro).equipo_en_uso = rand() % (*monstro).tope_equipo;

}

void curar(int* vida){
    (*vida) += 20;
}

void mostrar_monstro(monstro_t monstro){

    printf("================\n");
    printf("= %s \n", monstro.nombre);
    printf("= Vida: %i\n", monstro.vida);
    printf("= Ataque: %i\n", monstro.ataque);
    printf("= Defensa: %i\n", monstro.defensa);
    if (monstro.es_magico){
        printf("= Es mágico: SI\n");
    } else {
        printf("= Es mágico: NO\n");
    }
    printf("================\n");
}

void atacar(monstro_t atacante, monstro_t* atacado){

    int ptos_ataque = atacante.ataque + atacante.equipo[atacante.equipo_en_uso].plus_ataque;
    int ptos_defensa = ((*atacado).defensa) / 2 + (*atacado).equipo[(*atacado).equipo_en_uso].plus_defensa;

    (*atacado).vida = (*atacado).vida - ptos_ataque + ptos_defensa;
}
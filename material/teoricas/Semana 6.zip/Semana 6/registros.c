#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define MAX_NOMBRE 50
#define MAX_MONSTROS 50
#define MAX_EQUIPO 50
const int VIDA_INICIAL = 100;
const char TIERRA = 'T';
/*
estructuras
- un conjunto de campos
- otras estructuras
- tipos de dato simple
- me permiten representar algo

carta yugio:
- nombre    -> string
- vida      -> int
- ataque    -> int
- defensa   -> int
- es_magico -> bool
*/

typedef struct equipa {
    int plus_ataque;
    int plus_defensa;
} equipa_t;

typedef struct acompaniero {
    char nombre[MAX_NOMBRE];
    char tipo;
} acompaniero_t;

typedef struct monstro {
    char nombre[MAX_NOMBRE];
    int vida;
    int ataque;
    int defensa;
    bool es_magico;
    acompaniero_t acompaniero;
    equipa_t equipo[MAX_EQUIPO];
    int tope_equipo;
    int equipo_en_uso;
} monstro_t;

void inicializar_monstro(monstro_t* monstro){

    // printf("Vida: \n");
    // scanf("%i", &((*monstro).vida));

    printf("Nombre: \n");
    scanf("%s", (*monstro).nombre);

    (*monstro).vida = VIDA_INICIAL;
    monstro->vida = VIDA_INICIAL;

    /* son equivalentes */
    // (*_)._
    // _->_

    (*monstro).ataque = (rand() % 91) + 10;
    (*monstro).defensa = (rand() % 91) + 10;
    (*monstro).es_magico = !(rand() % 10);

    (*monstro).acompaniero.tipo = TIERRA;
    //monstro->acompaniero.tipo = TIERRA;
    (*monstro).tope_equipo = 0;
    (*monstro).equipo[0].plus_ataque = (rand() % 11);
    (*monstro).equipo[0].plus_defensa = (rand() % 11);
    ((*monstro).tope_equipo)++;

    (*monstro).equipo_en_uso = rand() % (*monstro).tope_equipo;

}

void curar(int* vida){
    (*vida) += 20;
}

void mostrar_monstro(monstro_t monstro){

    printf("================\n");
    printf("= %s \n", monstro.nombre);
    printf("= Vida: %i\n", monstro.vida);
    printf("= Ataque: %i\n", monstro.ataque);
    printf("= Defensa: %i\n", monstro.defensa);
    if (monstro.es_magico){
        printf("= Es mágico: SI\n");
    } else {
        printf("= Es mágico: NO\n");
    }
    printf("================\n");
}

void atacar(monstro_t atacante, monstro_t* atacado){

    int ptos_ataque = atacante.ataque + atacante.equipo[atacante.equipo_en_uso].plus_ataque;
    int ptos_defensa = ((*atacado).defensa) / 2 + (*atacado).equipo[(*atacado).equipo_en_uso].plus_defensa;

    (*atacado).vida = (*atacado).vida - ptos_ataque + ptos_defensa;
}

int main() {
    srand(time(NULL));
    /*
    monstro_t monstros[MAX_MONSTROS];
    int tope = 0;

    for (int i = 0; i < 4; i++) {
        inicializar_monstro(&(monstros[i]));
    }
    tope = 4;

    for (int i = 0; i < tope; i++) {
        mostrar_monstro((monstros[i]));
    }*/

    monstro_t charly, messi;

    inicializar_monstro(&messi);
    inicializar_monstro(&charly);

    mostrar_monstro(messi);
    mostrar_monstro(charly);
    
    char letra;
    scanf(" %c", &letra);
    atacar(messi, &charly);

    mostrar_monstro(messi);
    mostrar_monstro(charly);

    scanf(" %c", &letra);
    atacar(charly, &messi);

    mostrar_monstro(messi);
    mostrar_monstro(charly);

    curar(&(messi.vida));

    mostrar_monstro(messi);
    return 0;
}

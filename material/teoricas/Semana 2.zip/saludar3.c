#include<stdio.h>

int main(){
	// contador = contador + 1
	// contador++
	// contador += 1

	for(int contador = 2;contador <= 9;contador = contador + 2){
		printf("%i\n", contador);
	}

	return 0;
}

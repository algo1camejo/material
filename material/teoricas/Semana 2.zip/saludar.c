#include<stdio.h>
// std 	-> standard
// i 		-> input (entrada)
// o 		-> output (salida)

int main(){

	printf("Hola mundo :)\n");
	return 0;
}

#include<stdio.h>
// std 	-> standard
// i 		-> input (entrada)
// o 		-> output (salida)

int main(){

	// entero
	int numero;
	numero = 10;

	//
	int messi = 10;
	int neymar = 7;

	// operadores aritmeticos
	int ortigoza = messi + neymar + 3;
	int higuain = messi - 1;
	int masche = neymar * 2;
	// variable ya creada
	neymar = masche / 2;

	printf("El número de messi es %i y de neymar %i\n", messi, neymar);
	printf("%i\n", 8);
	return 0;
}

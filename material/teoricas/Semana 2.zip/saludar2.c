#include<stdio.h>

//CONSTANTES

const int MESSI = 10;
const int NEYMAR = 7;
const int ORTIGOZA = 20;

int main(){

	int camiseta = 20;

	printf("Ingrese un número de camiseta:");
	scanf("%i", &camiseta);

	if(camiseta == MESSI){
		printf("Holas Messis\n");
	} else if(camiseta == NEYMAR){
		printf("Oi Neymar\n");
	} else if(camiseta == ORTIGOZA){
		printf("Hola Ortigoza\n");
	} else {
		printf("Quien te conoce?\n");
	}

	return 0;
}

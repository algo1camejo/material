#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("Necesito el nombre del archivo de configuracion\n");
        return -1;
    }

    FILE* archivo_config = fopen(argv[1], "r");
    if (archivo_config == NULL) {
        perror("No se pudo abrir el archivo");
        return -2;
    }

    char nombre[20];
    int edad;

    char nombre_parametro[20];
    // char valor_parametro[20];
    while (!feof(archivo_config)) {
        fscanf(archivo_config, "%[^=]=", nombre_parametro);
        if (strcmp(nombre_parametro, "NOMBRE") == 0) {
            fscanf(archivo_config, "%[^\n]\n", nombre);
        } else if (strcmp(nombre_parametro, "EDAD") == 0) {
            fscanf(archivo_config, "%i\n", &edad);
        }
    }

    printf("Nombre: %s\n", nombre);
    printf("Edad: %i\n", edad);

    fclose(archivo_config);
}

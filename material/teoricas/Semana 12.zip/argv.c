#include <stdio.h>
#include <stdlib.h>

int fibonacci(int n) {
    if (n == 1 || n == 2) {
        return 1;
    }

    return fibonacci(n-1) + fibonacci(n-2);
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("Pasame un numero\n");
        return -1;
    }

    // array to integer
    if (argv[1][0] < '0' || argv[1][0] > '9') {
        printf("Eso no es un numero\n");
        return -1;
    }

    int numero = atoi(argv[1]);
    printf("%i\n", fibonacci(numero));

    return 0;
}

// argc --> Argument count
// argv --> Argument vector

#include <stdio.h>
#include <string.h>

int main() {
    FILE* peliculas = fopen("./Peliculas.txt", "r");
    if (peliculas == NULL) {
        perror("Error al abrir el archivo de lectura");
        return -1;
    }

    FILE* nuevo_archivo = fopen("./nuevo_archivo.txt", "w");
    if (nuevo_archivo == NULL) {
        fclose(peliculas);
        perror("Error al abrir el archivo de escritura");
        return -1;
    }

    char pelicula[200];
    while (!feof(peliculas)) {
        fscanf(peliculas, "%[^\n]\n", pelicula);
        if (strncmp(pelicula, "El", 2) == 0) {
            fprintf(nuevo_archivo, "%s\n", pelicula);
        }
    }

    fclose(peliculas);
    fclose(nuevo_archivo);

    return 0;
}

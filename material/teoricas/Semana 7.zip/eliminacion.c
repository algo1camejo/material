-- Hard delete --
1. Si el vector NO está ordenado, me conviene pasar el del final al hueco

2. Si está ordenado muevo hacia adelante los elementos

-- Soft delete --
1. Agregar un campo de estado


typedef struct carta {
    int numero;
    char palo;
    bool fue_jugada;
} carta_t;

typedef struct usuario {
    ...
    bool activo;
} usuario_t;

int main(){

    carta_t mano_manu_b[MAX_MANO];
    int tope_mano_manu_b;
    carta_t mano_manu_c[MAX_MANO];
    int tope_mano_manu_c;

    mano_manu_b[0].palo = 'C';
    mano_manu_b[1].palo = 'B';
    mano_manu_b[2].palo = 'E';
    mano_manu_b[0].numero = 4;
    mano_manu_b[1].numero = 4;
    mano_manu_b[2].numero = 4;
    tope_mano_manu_b = 3;

    mano_manu_c[0].palo = 'E';
    mano_manu_c[1].palo = 'E';
    mano_manu_c[2].palo = 'E';
    mano_manu_c[0].numero = 1;
    mano_manu_c[1].numero = 7;
    mano_manu_c[2].numero = 6;
    tope_mano_manu_c = 3;


    // Manu B juega el 4 de copas
    // un vector NO ordenado
    mano_manu_b[0] = 
        mano_manu_b[tope_mano_manu_b - 1];
    tope_mano_manu_b--;


    // OTRO VECTOR, NADA QUE VER
    // UN VECTOR ORDENADO
    for (int i = la_siguiente_a_la_que_quiero_sacar ; i < tope; i++){
        mano[i-1] = mano[i];
    }
    tope--;


    // soft delete
    mano[1].fue_jugada = true;


}

typedef struct carta {
    int numero;
    char palo;
} carta_t;

// Pos: Devolvera -1 si carta1 < carta2.
//      Devolvera 1 si carta1 > carta2.
//      Devolvera 0 si son iguales.
int comparacion(carta_t carta1, carta_t carta2) {
    if (carta1.numero < carta2.numero) {
        return -1;
    } else if (carta1.numero > carta2.numero) {
        return 1;
    } else { // carta1.numero == carta2.numero
        if (carta1.palo < carta2.palo) {
            return -1;
        } else if (carta1.palo > carta2.palo) {
            return 1;
        }
    }

    return 0;
}

/* Burbujeo */
void ordenar_por_burbujeo(int vector[MAX], int tope){
    int aux;
    for (int i = 1; i < tope; i++) {
        for (int j = 0; j < tope - i; j++){
            int cmp = comparacion(vector[j], vector[j+1]);
            if (cmp < 0) {
                aux = vector[j];
                vector[j] = vector[j+1];
                vector[j+1] = aux;
            }
        }

    }
}

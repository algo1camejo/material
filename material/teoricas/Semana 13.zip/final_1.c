#include<stdio.h>
#include<stdlib.h>

#define MAX_PALABRA 50
const char SEPARADOR = ' ';

int main(int argc, char* argv[]){
    FILE* palabras = fopen(argv[1], "r");
    if (palabras == NULL) {
        perror("El archivo no lo pude abrir!");
        return -1;
    }

    FILE* contrasenia = fopen(argv[2], "w");
    if (contrasenia == NULL) {
        fclose(palabras);
        perror("No pude abrir el de salida!");
        return -2;
    }

    int pos_caracter;
    char palabra[MAX_PALABRA];

    int leidos = fscanf(palabras, "%i;%s\n", &pos_caracter, palabra);
    while(leidos == 2){
        if(pos_caracter == 0){
            fprintf(contrasenia, "%c", SEPARADOR);
        } else if (pos_caracter > 0) {
            fprintf(contrasenia, "%c", palabra[pos_caracter-1]);
        }
        leidos = fscanf(palabras, "%i;%s\n", &pos_caracter, palabra);
    }
   
    fclose(palabras);
    fclose(contrasenia);

    return 0;
}
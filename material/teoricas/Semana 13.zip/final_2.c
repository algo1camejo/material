#include<stdio.h>
#include<stdlib.h>

const int VUELTA_ENTERA = 360;
const char MANO = 'M';

int main(int argc, char* argv[]){
    
    FILE* tramos = fopen(argv[1], "r");
    if (tramos == NULL) {
        perror("El archivo no lo pude abrir!");
        return -1;
    }

    FILE* vueltas = fopen(argv[2], "w");
    if (vueltas == NULL) {
        fclose(tramos);
        perror("No pude abrir el de salida!");
        return -2;
    }

    char sentido;
    int recorrido;
    int total = 0;

    int leidos = fscanf(tramos, "%c;%i\n", &sentido, &recorrido);
    while(leidos == 2){
        /*
        if (sentido == 'M')
            total += recorrido;
        else
            total -= recorrido;
        */
        //total += ((sentido == 'M') ? recorrido : (-1)*recorrido);
        total += recorrido * ((sentido == MANO) ? 1 : -1);

        leidos = fscanf(tramos, "%c;%i\n", &sentido, &recorrido);
    }

    fprintf(vueltas, "%i vueltas", total/VUELTA_ENTERA);
   
    fclose(tramos);
    fclose(vueltas);

    return 0;
}
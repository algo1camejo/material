/* 
 * Recibir un nombre de archivo
 * un string y una letra
 * por linea de comando
 * y reemplazar cada una de las
 * letras del string que aparezca en el
 * archivo por la letra recibida.
 * Ejemplo:
 * ./ejercicio1 un_archivo.c  aeou     i
 *     argv[0]   argv[1]     argv[2] argv[3]  
 */
#include<string.h>
#include<stdio.h>
#include<stdlib.h>

int main(int argc, char* argv[]){
    char letra_nueva = argv[3][0];

    FILE* texto = fopen(argv[1], "r");
    if (texto == NULL) {
        perror("El archivo no essisste o no lo pude abrir!");
        return -1;
    }

    FILE* auxiliar = fopen("auxiliar.txt", "w");
    if (auxiliar == NULL) {
        fclose(texto);
        perror("No pude abrir el aussiliar!");
        return -2;
    }

    /*
    -> scanf("%i/%i/%i", &dia, &mes, &anio);
    -> 15/11/2022 -> 3
    -> dvsivmioavno nnoe -> 0
    -> 15/11v vrbvewdx -> 2
    */

    char letra;
    int leidos = fscanf(texto, "%c", &letra);// -> 0 o 1
    while(leidos == 1){
        letra = (strchr(argv[2], letra) == NULL) ? letra : letra_nueva;
        fprintf(auxiliar, "%c", letra);
        leidos = fscanf(texto, "%c", &letra);
    }

    fclose(texto);
    fclose(auxiliar);
    rename("auxiliar.txt", argv[1]);

    return 0;
}
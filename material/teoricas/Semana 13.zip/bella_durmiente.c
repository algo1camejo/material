#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<string.h>

#define MAX_MOMENTO 50
#define MAX_MOMENTOS 3

int main(int argc, char* argv[]){
    
    FILE* suenios = fopen(argv[1], "r");
    if (suenios == NULL) {
        perror("El archivo no lo pude abrir!");
        return -1;
    }

    FILE* descanso = fopen(argv[2], "w");
    if (descanso == NULL) {
        fclose(suenios);
        perror("No pude abrir el de salida!");
        return -2;
    }

    char tipo;
    int minutos;
    char momentos[MAX_MOMENTOS][MAX_MOMENTO];

    int minutos_descansados = 0;
    bool descanso_activado = false;

    // int leidos = fscanf(suenios, "%c;%i;%[^;];%[^;];%[^\n]\n", &tipo, &minutos, momentos[0], momentos[1], momentos[2]);
    // while(leidos == 5){

    //     if (tipo == 'I' || tipo == 'F'){
    //         minutos_descansados += minutos;
    //         if (tipo == 'I') {
    //             descanso_activado = true;
    //         } else {
    //             descanso_activado = false;
    //         }
    //     } else {
    //         if (descanso_activado && 
    //             (!strcmp(momentos[0], "principe") || 
    //              !strcmp(momentos[1], "principe") || 
    //              !strcmp(momentos[2], "principe"))){
    //             minutos_descansados += minutos;
    //         }
    //     }

    //     leidos = fscanf(suenios, "%c;%i;%[^;];%[^;];%[^\n]\n", &tipo, &minutos, momentos[0], momentos[1], momentos[2]);
    // }

    int leidos = fscanf(suenios, "%c;%i;%[^;];%[^;];%[^\n]\n", &tipo, &minutos, momentos[0], momentos[1], momentos[2]);
    while(leidos == 5){

        if (tipo == 'I'){
            minutos_descansados += minutos;
            leidos = fscanf(suenios, "%c;%i;%[^;];%[^;];%[^\n]\n", &tipo, &minutos, momentos[0], momentos[1], momentos[2]);
            while (tipo != 'F' && leidos == 5){
                if (!strcmp(momentos[0], "principe") || 
                    !strcmp(momentos[1], "principe") || 
                    !strcmp(momentos[2], "principe")){
                    minutos_descansados += minutos;
                }
                leidos = fscanf(suenios, "%c;%i;%[^;];%[^;];%[^\n]\n", &tipo, &minutos, momentos[0], momentos[1], momentos[2]);
            }
            minutos_descansados += minutos;
        }

        leidos = fscanf(suenios, "%c;%i;%[^;];%[^;];%[^\n]\n", &tipo, &minutos, momentos[0], momentos[1], momentos[2]);
    }

    int horas = minutos_descansados / 60;
    int minutos_resto = minutos_descansados % 60;
    
    fprintf(descanso, "%ih%im", horas, minutos_resto);

    fclose(suenios);
    fclose(descanso);

    return 0;
}
#include<stdio.h>
#include <stdlib.h>

const int MAX_CARTAS = 4;
const int CARTA_MAXIMA = 13;

void intercambiar(int* un_numero, int* otro_numero){
    int aux = *un_numero;

    *un_numero = *otro_numero;
    *otro_numero = aux;
}

void inicializar_cartas(int cartas[MAX_CARTAS]){

	for(int i = 0; i < MAX_CARTAS;  i++){
		cartas[i] = (rand() % CARTA_MAXIMA)+1;
	}
}

int puntaje(int cartas[MAX_CARTAS]){

	int suma = 0;

	for(int i = 0; i < MAX_CARTAS; i++){
		suma += cartas[i];
	}

	return suma;
}

int main(){
	srand(100);
	int cartas_tomi[MAX_CARTAS];
	int cartas_manu[MAX_CARTAS];

	inicializar_cartas(cartas_tomi);
	inicializar_cartas(cartas_manu);

	int puntaje_manu = puntaje(cartas_manu);
	int puntaje_tomi = puntaje(cartas_tomi);

	if(puntaje_tomi > puntaje_manu){
		printf("ESTO NUNCA PASA (gano Manu)\n");
	} else if (puntaje_tomi < puntaje_manu){
		printf("Gana Tomi\n");
	} else {
		printf("Empate\n");
	}

	return 0;
}
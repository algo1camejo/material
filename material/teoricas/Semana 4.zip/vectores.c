#include<stdio.h>
#include<stdlib.h>

const int CANT_COLABS_ACTUAL = 30;
const int MAX_COLABS = 100;
const int EDAD_MAX = 150;

void inicializar_edades(int edades[MAX_COLABS], int* tope){

	for(; *tope < CANT_COLABS_ACTUAL;  (*tope)++){
		edades[*tope] = rand() % EDAD_MAX+1;
	}
}

void mostrar_edades(int edades[MAX_COLABS], int tope){

	for(int i = 0; i < tope; i++){
		printf("%i\n", edades[i]);
	}
}

float promedio_edades(int edades[MAX_COLABS], int tope){

	float suma = 0;

	for(int i = 0; i < tope; i++){
		suma += edades[i];
		//suma = suma + edades[i];
	}

	return suma/tope;
}


int main(){
	srand(0);

	int edades[MAX_COLABS];
	int tope = 0;

	inicializar_edades(edades, &tope);

	mostrar_edades(edades, tope);

	printf("La edad promedio es: %f", promedio_edades(edades, tope));


	return 0;
}
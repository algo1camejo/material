#include<stdio.h>
#define MAX_VECTOR 100

int busqueda_binaria_iterativa(int vector[MAX_VECTOR], int tope, int buscado){
	
	int inicio = 0;
	int final = tope - 1;
	int centro = (inicio + final) / 2;

	while(inicio <= final && vector[centro] != buscado){
		if(vector[centro] > buscado)
			final = centro - 1;
		else //if (vector[centro] < buscado)
			inicio = centro + 1;

		centro = (inicio + final) / 2;
	}

	// operador ternario
	return (vector[centro] == buscado) ? centro : -1;
}


int busqueda_binaria_rec(int vector[MAX_VECTOR], int inicio, int fin, int buscado){

	if (inicio > fin) return -1;

	int centro = (inicio + fin) / 2;
	if (vector[centro] == buscado)
		return centro;
	else if (vector[centro] < buscado)
		return busqueda_binaria_rec(vector, centro+1, fin, buscado);
	else
		return busqueda_binaria_rec(vector, inicio, centro-1, buscado);
}


int busqueda_binaria(int vector[MAX_VECTOR], int tope, int buscado){
	return busqueda_binaria_rec(vector, 0, tope-1, buscado);
}


int main(){

	int vector[MAX_VECTOR] = {1,34,765,3244,45654,983432,2134253};
	int pos = busqueda_binaria(vector, 7, 45);
	if (pos == -1){
		printf("El elemento %i no está en el vector.\n", 45);
	} else {
		printf("El elemento %i está en la posición %i.\n", 45, pos);
	}

	pos = busqueda_binaria(vector, 7, 983432);
	if (pos == -1){
		printf("El elemento %i no está en el vector.\n", 983432);
	} else {
		printf("El elemento %i está en la posición %i.\n", 983432, pos);
	}

}


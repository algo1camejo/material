- factorial
- fibonacci

void contar(int n){
	for(int i = 1; i<=n; i++){
		printf("%i\n", i);
	}
}

void contar(int n){
	/* caso base */
	if (n == 0) return;

	/* proceso */
	print("%i\n", n);

	/* llamada recursiva */
	contar(n-1);
}

void contar(int n){
	contar_rec(n, 1);
}

void contar_rec(int n, int actual){
	if (actual > n) return;
	print("%i\n", actual);
	contar_rec(n, actual+1);
}


void deletrear(char frase[MAX_FRASE]){
	deletrear_rec(frase, 0);
}

"hoy no dormi"
void deletrear_rec(char frase[MAX_FRASE], int letra_actual){
	// condicion de corte
	if (frase[letra_actual] == '\0') return;
	//if (strlen(frase) == actual) return;

	if (frase[letra_actual] != ' ')
		print("%c\n", frase[letra_actual]);

	deletrear_rec(frase, letra_actual+1);
}






"hoy no dormi"
-> hiy ni dirmi
void burlarme_rec(char frase[MAX_FRASE], int letra_actual){
	// condicion de corte
	if (frase[letra_actual] == '\0') return;

	if (es_vocal(frase[letra_actual])
		frase[letra_actual] = 'i';

	burlarme_rec(frase, letra_actual+1);
}

eeste año\0
    |
         año\0



void cargares(char frase[MAX_FRASE], int ac, int cant) {
	for(int i = strlen(frase); i > actual; i--){
		frase[i+cant] = frase[i];
	}
	for (int i = ac+1; i < ac+cant; i++){
		frase[i] = 'e';
	}
}

void elegnatizar_rec(frase[MAX_FRASE], int actual, int cant_e_vistas){

	if (frase[actual] == '\0') return;

	int salto = 1;
	if (frase[actual] == 'e'){
		cant_e_vistas++;
		cargares(frase, actual, cant_e_vistas);
		salto = cant_e_vistas
	}

	elegantizar_rec(frase, actual+salto, cant_e_vistas);
}




























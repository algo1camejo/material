#include<stdio.h>
#include<string.h>

#define MAX_FRASE 100

void cargares(char frase[MAX_FRASE], int ac, int cant) {
	for(int i = strlen(frase); i > ac; i--){
		frase[i+cant] = frase[i];
	}
	for (int i = ac+1; i <= ac+cant; i++){
		frase[i] = 'e';
	}
}

void elegnatizar_rec(char frase[MAX_FRASE], int actual, int cant_e_vistas){

	if (frase[actual] == '\0') return;

	int salto = 1;
	if (frase[actual] == 'e'){
		cant_e_vistas++;
		cargares(frase, actual, cant_e_vistas);
		salto = cant_e_vistas+1;
	}

	elegnatizar_rec(frase, actual+salto, cant_e_vistas);
}


int main(){
	
	char frase[MAX_FRASE] = "el elefante de elegante tiene el esternon estafado";

	elegnatizar_rec(frase, 0, 0);

	printf("%s\n", frase);

}




